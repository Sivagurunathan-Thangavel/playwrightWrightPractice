import { expect, test, request } from '@playwright/test'
const ApiUtils = require('.utils/ApiUtils')

const loginPayload = { userEmail: "sg.nathi08@gmail.com", userPassword: "Test@123" }
const orderPayload = { orders: [{ country: "British Indian Ocean Territory", productOrderedId: "6581cade9fd99c85e8ee7ff5" }] }
let response;

test.beforeAll(async () => {
    const apiContext = await request.newContext();
    const apiUtils = new ApiUtils(apiContext, loginPayload);
    response = await apiUtils.createOrder(orderPayload);
})



test('Launch the browser via API without entering username and password', async ({ page }) => {

    await page.addInitScript(value => {
        window.localStorage.setItem('token', value) // setting the token as key value pair in windows refer V: 42, 43
    }, response.token)

    await page.goto('https://rahulshettyacademy.com/client');
    await page.waitForLoadState('networkidle');
    await page.locator("div[class='card-body']").first().waitFor();
    const products = page.locator("div[class='card-body']");
    const productCount = await products.count();
    console.log(`The product count is : ${productCount}`);
})